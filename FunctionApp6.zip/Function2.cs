using System;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;

using System.Xml;
using System.Xml.Schema;

using Microsoft.Azure;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Table;

using System.IO;
using System.Xml.Linq;

namespace FunctionApp6
{
    public static class Function2
    {
        private static CloudStorageAccount storageAccount = CloudStorageAccount.Parse(CloudConfigurationManager.GetSetting("StorageConnectionString"));
        private static CloudTable table = storageAccount.CreateCloudTableClient().GetTableReference("status1");

        [FunctionName("Function2")]
        public static void Run([QueueTrigger("myqueue-xml", Connection = "AzureWebJobsStorage")]string myQueueItem, TraceWriter log)
        {
            log.Info($"C# Queue trigger function processed: {myQueueItem}");
            ProcessXmlAsync(myQueueItem, log);
            //ProcessXmlAsync(myQueueItem);

        }

        //private static int ProcessXmlAsync(QueueEntity myQueueItem)
        private static int ProcessXmlAsync(string myQueueItem, TraceWriter log)
        {
            string[] sep = new string[] { "#<>#"};
            string requesNumber = myQueueItem.Split(sep, StringSplitOptions.None)[0];
            string xml = myQueueItem.Split(sep, StringSplitOptions.None)[1];

            string xmlSchema = CloudConfigurationManager.GetSetting("xsdString");
            log.Info($"C# Queue trigger function xsd: {xmlSchema}");
            XmlSchemaSet schemas = new XmlSchemaSet();
            schemas.Add("", XmlReader.Create(new StringReader(xmlSchema)));
            XDocument doc2 = XDocument.Parse(xml);
            string returnString = "XML Schema validation succeded";
            log.Info($"C# Queue trigger function returnString1: {returnString}");
            doc2.Validate(schemas, (o, e) =>
            {
                returnString = e.Message;
            });
            // Create a new customer entity.
            log.Info($"C# Queue trigger function returnString2: {returnString}");
            StatusEntity status1 = new StatusEntity(requesNumber, "xmlPost");
            status1.status = returnString;
            TableOperation insertOperation = TableOperation.InsertOrReplace(status1);
            CloudStorageAccount storageAccount = CloudStorageAccount.Parse(CloudConfigurationManager.GetSetting("StorageConnectionString"));
            CloudTable table = storageAccount.CreateCloudTableClient().GetTableReference("status1");
            log.Info($"C# Queue trigger function returnString3: {returnString}");
            table.CreateIfNotExists();
            TableResult result = table.Execute(insertOperation);
            return 1;
        }
    }
    public class StatusEntity : TableEntity
    {
        public StatusEntity(string id, string status)
        {
            this.PartitionKey = status;
            this.RowKey = id;
        }
        public StatusEntity() { }
        public string status { get; set; }
    }
}
