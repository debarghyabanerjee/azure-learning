using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Host;

using Serilog;
using Serilog.Sinks.AzureWebJobsTraceWriter;

namespace FunctionApp6
{
    public static class Function1
    {
        private static int requesNumber = 0;

        [FunctionName("Function1")]
        public static async Task<HttpResponseMessage> Run([HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)]HttpRequestMessage req, [Queue("myqueue-xml", Connection = "AzureWebJobsStorage")] ICollector<string> myQueueItem, TraceWriter traceWriter)
        {
            traceWriter.Info("C# HTTP trigger function processed a request.");
            requesNumber += 1;
            string xml = await req.Content.ReadAsStringAsync();
            var log = new LoggerConfiguration()
                .WriteTo.RollingFile("log-{Date}.txt")
                .WriteTo.TraceWriter(traceWriter)
                .WriteTo.Stackify()
                .CreateLogger();

            log.Information("serilog: " + xml);
            traceWriter.Info(xml);
            
            myQueueItem.Add(requesNumber.ToString() + "#<>#" + xml);
            return  req.CreateResponse(HttpStatusCode.OK, "Requestet submitted successfully: " + requesNumber.ToString());
        }
    }

    public class QueueEntity 
    {
        private int requestNumber;
        private string xml;
        public QueueEntity(int requestNumber, string xml)
        {
            this.requestNumber = requestNumber;
            this.xml = xml;
        }

        public int get_requestNumber ()
        {
            return this.requestNumber;
        }
        public string get_xml()
        {
            return this.xml;
        }
    }
}
